Welcome to FMOD for Unity

This package allows you to easily play back audio events created in FMOD Studio
within your Unity project.

The best place to start is with our online documentation:
https://fmod.com/docs/2.02/unity

If you prefer a more step-by-step guide, try our integration tutorial that
builds on the familiar Karting Microgame:
https://fmod.com/unity-integrate

For support, join the conversation on our Unity forums:
https://qa.fmod.com/c/unity
